// code.js — Banner Resizer Plugin

figma.showUI(__html__, { width: 340, height: 480, title: "Banner Resizer" });

// ─── Get selected frame ───────────────────────────────────────────────────────

function getSelectedFrame() {
  var sel = figma.currentPage.selection;
  if (!sel || sel.length === 0) return { node: null, error: "No frame selected." };
  if (sel.length > 1) return { node: null, error: "Select only one frame." };
  var node = sel[0];
  if (node.type !== "FRAME" && node.type !== "COMPONENT" && node.type !== "INSTANCE")
    return { node: null, error: '"' + node.name + '" is not a frame.' };
  return { node: node, error: null };
}

// ─── Find Component Set instance inside a frame ───────────────────────────────

function findComponentSetInstance(node) {
  // Find first INSTANCE whose mainComponent belongs to a COMPONENT_SET
  var instances = node.findAll(function(n) { return n.type === "INSTANCE"; });
  for (var i = 0; i < instances.length; i++) {
    var inst = instances[i];
    if (inst.mainComponent && inst.mainComponent.parent && inst.mainComponent.parent.type === "COMPONENT_SET") {
      return inst;
    }
  }
  return null;
}

// ─── Find best matching variant by ratio ──────────────────────────────────────

function getBestVariant(componentSet, targetW, targetH) {
  var targetRatio = targetW / targetH;
  var best = null;
  var bestDiff = Infinity;
  for (var i = 0; i < componentSet.children.length; i++) {
    var variant = componentSet.children[i];
    var diff = Math.abs((variant.width / variant.height) - targetRatio);
    if (diff < bestDiff) { bestDiff = diff; best = variant; }
  }
  return best;
}

// ─── Detach all instances ─────────────────────────────────────────────────────

function detachAllInstances(node) {
  if (!node.children) return;
  for (var i = node.children.length - 1; i >= 0; i--) {
    var child = node.children[i];
    if (child.type === "INSTANCE") child.detachInstance();
    else detachAllInstances(child);
  }
}

// ─── Snapshot by path (survives detach which changes node IDs) ────────────────

function getNodePath(node, root) {
  var path = [];
  var current = node;
  while (current && current.id !== root.id) {
    path.unshift(current.name + "_" + current.parent.children.indexOf(current));
    current = current.parent;
  }
  return path.join("/");
}

function snapshotByPath(node, root, map) {
  var path = getNodePath(node, root);
  map[path] = { x: node.x, y: node.y, width: node.width, height: node.height };
  if (node.children) {
    for (var i = 0; i < node.children.length; i++) snapshotByPath(node.children[i], root, map);
  }
}

function applySnapshotByPath(node, root, map, rx, ry, oldParentW, oldParentH) {
  if (!node.children) return;
  var newParentW = oldParentW * rx;
  var newParentH = oldParentH * ry;

  for (var i = 0; i < node.children.length; i++) {
    var child = node.children[i];
    var path = getNodePath(child, root);
    var s = map[path];

    if (!s) { applySnapshotByPath(child, root, map, rx, ry, child.width, child.height); continue; }

    var oldChildX = s.x; var oldChildY = s.y;
    var oldChildW = s.width; var oldChildH = s.height;
    var parentIsAutoLayout = node.layoutMode !== undefined && node.layoutMode !== "NONE";
    var childIsAbsolute = child.layoutPositioning === "ABSOLUTE";

    if (!parentIsAutoLayout || childIsAbsolute) {
      var c = child.constraints || { horizontal: "MIN", vertical: "MIN" };
      var h = c.horizontal; var v = c.vertical;

      if (child.type !== "GROUP" && child.type !== "TEXT") {
        try { child.resize(Math.round(oldChildW * rx), Math.round(oldChildH * ry)); } catch (e) { console.error("resize [" + child.name + "]:", e); }
      }
      if (h === "MIN" || h === "SCALE") {
        try { child.x = Math.round(oldChildX * rx); } catch (e) {}
      } else if (h === "MAX") {
        var dfr = oldParentW - oldChildX - oldChildW;
        try { child.x = Math.round(newParentW - (dfr * rx) - child.width); } catch (e) {}
      } else if (h === "CENTER") {
        try { child.x = Math.round((oldChildX + oldChildW / 2) * rx - child.width / 2); } catch (e) {}
      }
      if (v === "MIN" || v === "SCALE") {
        try { child.y = Math.round(oldChildY * ry); } catch (e) {}
      } else if (v === "MAX") {
        var dfb = oldParentH - oldChildY - oldChildH;
        try { child.y = Math.round(newParentH - (dfb * ry) - child.height); } catch (e) {}
      } else if (v === "CENTER") {
        try { child.y = Math.round((oldChildY + oldChildH / 2) * ry - child.height / 2); } catch (e) {}
      }
    }
    applySnapshotByPath(child, root, map, rx, ry, oldChildW, oldChildH);
  }
}

// ─── Scale style properties ───────────────────────────────────────────────────

function scaleStyleProperties(node, ratio) {
  try {
    if (node.layoutMode !== undefined && node.layoutMode !== "NONE") {
      if (typeof node.paddingTop    === "number") node.paddingTop    = Math.round(node.paddingTop    * ratio);
      if (typeof node.paddingBottom === "number") node.paddingBottom = Math.round(node.paddingBottom * ratio);
      if (typeof node.paddingLeft   === "number") node.paddingLeft   = Math.round(node.paddingLeft   * ratio);
      if (typeof node.paddingRight  === "number") node.paddingRight  = Math.round(node.paddingRight  * ratio);
      if (typeof node.itemSpacing   === "number") node.itemSpacing   = Math.round(node.itemSpacing   * ratio);
      if (typeof node.counterAxisSpacing === "number") node.counterAxisSpacing = Math.round(node.counterAxisSpacing * ratio);
    }
    if (typeof node.cornerRadius === "number") {
      node.cornerRadius = Math.round(node.cornerRadius * ratio);
    } else {
      if (typeof node.topLeftRadius     === "number") node.topLeftRadius     = Math.round(node.topLeftRadius     * ratio);
      if (typeof node.topRightRadius    === "number") node.topRightRadius    = Math.round(node.topRightRadius    * ratio);
      if (typeof node.bottomLeftRadius  === "number") node.bottomLeftRadius  = Math.round(node.bottomLeftRadius  * ratio);
      if (typeof node.bottomRightRadius === "number") node.bottomRightRadius = Math.round(node.bottomRightRadius * ratio);
    }
    if (typeof node.strokeWeight === "number") node.strokeWeight = Math.max(0.01, node.strokeWeight * ratio);
  } catch (e) {}
  if (!node.children) return;
  for (var i = 0; i < node.children.length; i++) scaleStyleProperties(node.children[i], ratio);
}

// ─── Scale all text ───────────────────────────────────────────────────────────

async function scaleAllText(rootNode, ratio) {
  var textNodes = rootNode.findAll(function(n) { return n.type === "TEXT"; });
  for (var i = 0; i < textNodes.length; i++) {
    var t = textNodes[i];
    try {
      if (t.fontName !== figma.mixed) {
        await figma.loadFontAsync(t.fontName);
      } else {
        var seen = new Map();
        for (var c = 0; c < t.characters.length; c++) {
          var f = t.getRangeFontName(c, c + 1);
          if (f !== figma.mixed) seen.set(f.family + "::" + f.style, f);
        }
        var fl = [];
        seen.forEach(function(font) { fl.push(font); });
        for (var fi = 0; fi < fl.length; fi++) await figma.loadFontAsync(fl[fi]);
      }
      if (t.fontSize !== figma.mixed) {
        t.fontSize = Math.max(1, Math.round(t.fontSize * ratio));
      } else {
        for (var ci = 0; ci < t.characters.length; ci++) {
          var sz = t.getRangeFontSize(ci, ci + 1);
          if (sz !== figma.mixed) t.setRangeFontSize(ci, ci + 1, Math.max(1, Math.round(sz * ratio)));
        }
      }
      if (t.lineHeight !== figma.mixed && t.lineHeight.unit === "PIXELS")
        t.lineHeight = { unit: "PIXELS", value: Math.max(1, Math.round(t.lineHeight.value * ratio)) };
      if (t.letterSpacing !== figma.mixed && t.letterSpacing.unit === "PIXELS")
        t.letterSpacing = { unit: "PIXELS", value: Math.round(t.letterSpacing.value * ratio) };
    } catch (e) { console.error("scaleAllText [" + t.name + "]:", e); }
  }
}

// ─── Main: clone frame, switch variant, scale ─────────────────────────────────

async function createBanner(master, newW, newH, label) {
  var oldW = master.width;
  var oldH = master.height;
  var ratioX = newW / oldW;
  var ratioY = newH / oldH;
  var ratio  = Math.sqrt(ratioX * ratioY);
  console.log("ratioX=" + ratioX + " ratioY=" + ratioY + " ratio=" + ratio);

  // STEP 1: Snapshot master BEFORE clone — clean original positions
  var masterSnap = {};
  snapshotByPath(master, master, masterSnap);

  // STEP 2: Clone the frame and place on page
  var clone = master.clone();
  figma.currentPage.appendChild(clone);
  clone.name = label || ("Banner " + newW + "x" + newH);
  clone.x = master.x + master.width + 100;
  clone.y = master.y;

  // STEP 3: Find the Component Set instance inside the clone
  var inst = findComponentSetInstance(clone);
  if (inst) {
    var componentSet = inst.mainComponent.parent; // the COMPONENT_SET
    var bestVariant = getBestVariant(componentSet, newW, newH);
    if (bestVariant) {
      console.log("Switching to variant: " + bestVariant.name + " (" + bestVariant.width + "x" + bestVariant.height + ")");
      try { inst.swapComponent(bestVariant); } catch (e) { console.error("swapComponent failed:", e); }
    }
  } else {
    console.log("No Component Set instance found inside frame — proceeding without variant switch.");
  }

  // STEP 4: Snapshot HUG sizing before any resize
  var allNodes = clone.findAll(function(n) { return true; });
  allNodes.push(clone);
  var hugSnaps = [];
  for (var i = 0; i < allNodes.length; i++) {
    var n = allNodes[i];
    if (n.layoutSizingHorizontal !== undefined || n.layoutSizingVertical !== undefined)
      hugSnaps.push({ node: n, h: n.layoutSizingHorizontal, v: n.layoutSizingVertical });
  }

  // STEP 5: Detach all instances (including the now-switched variant)
  detachAllInstances(clone);

  // STEP 6: Resize root frame
  clone.resize(newW, newH);

  // STEP 7: Scale positions/sizes using master snapshot
  applySnapshotByPath(clone, clone, masterSnap, ratioX, ratioY, oldW, oldH);

  // STEP 8: Scale style properties
  scaleStyleProperties(clone, ratio);

  // STEP 9: Scale fonts
  await scaleAllText(clone, ratio);

  // STEP 10: Restore HUG — must be last
  for (var i = 0; i < hugSnaps.length; i++) {
    var s = hugSnaps[i];
    try {
      if (s.h === "HUG") s.node.layoutSizingHorizontal = "HUG";
      if (s.v === "HUG") s.node.layoutSizingVertical   = "HUG";
    } catch (_) {}
  }

  figma.viewport.scrollAndZoomIntoView([clone]);
  return clone;
}

// ─── Selection info ───────────────────────────────────────────────────────────

function sendSelectionInfo() {
  var result = getSelectedFrame();
  if (!result.node) {
    figma.ui.postMessage({ type: "SELECTION_INFO", found: false, error: result.error });
    return;
  }
  var node = result.node;

  // Check if it contains a Component Set instance
  var inst = findComponentSetInstance(node);
  var variants = [];
  if (inst) {
    var cs = inst.mainComponent.parent;
    for (var i = 0; i < cs.children.length; i++) {
      var v = cs.children[i];
      variants.push({ name: v.name, width: Math.round(v.width), height: Math.round(v.height) });
    }
  }

  figma.ui.postMessage({
    type: "SELECTION_INFO",
    found: true,
    name: node.name,
    width: Math.round(node.width),
    height: Math.round(node.height),
    hasComponentSet: inst !== null,
    variants: variants,
  });
}

figma.on("selectionchange", sendSelectionInfo);

// ─── Message handler ──────────────────────────────────────────────────────────

figma.ui.onmessage = async function(msg) {
  if (msg.type === "GET_SELECTION_INFO") { sendSelectionInfo(); return; }

  if (msg.type === "CREATE_BANNER") {
    var width = msg.width; var height = msg.height;
    if (!width || !height || width <= 0 || height <= 0) {
      figma.ui.postMessage({ type: "ERROR", message: "Please enter valid width and height." });
      return;
    }
    var sel = getSelectedFrame();
    if (!sel.node) { figma.ui.postMessage({ type: "ERROR", message: sel.error }); return; }
    try {
      figma.ui.postMessage({ type: "LOADING" });
      var clone = await createBanner(sel.node, width, height, msg.label);
      figma.ui.postMessage({ type: "SUCCESS", message: 'Created "' + clone.name + '" (' + width + 'x' + height + ')' });
    } catch (err) {
      figma.ui.postMessage({ type: "ERROR", message: "Error: " + err.message });
    }
    return;
  }

  if (msg.type === "CLOSE") figma.closePlugin();
};
